export const Lista = () => {
    return (
        <div className="h-screen bg-amber-300 text-black ">
            <span>Tareas</span>
        </div>
    );
};